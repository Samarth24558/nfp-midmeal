from .models import *

from django.contrib import admin
admin.site.register(contact)
admin.site.register(feedback)
admin.site.register(foodbook)
# Register your models1 here.
